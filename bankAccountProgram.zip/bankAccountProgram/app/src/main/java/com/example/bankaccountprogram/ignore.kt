package com.example.bankaccountprogram

fun main(){
    /*
    val shoppin = mutableListOf("CPU","Ram","GPU", "Mother board")
    shoppin.set(1, "I DONT HAVE MONEY")
    println(shoppin)

     */

    val fruitslist = mutableListOf("Apple", "Watermelon", "Orange", "Melon")
    fruitslist.add("Jackfruit")
    print(fruitslist)
    fruitslist.remove("Apple")
    print(fruitslist)
    val truth = fruitslist.contains("Apple")
    println(truth)
    if(truth == true){
        println("booty")
    } else{
        println("no booty")
    }
}