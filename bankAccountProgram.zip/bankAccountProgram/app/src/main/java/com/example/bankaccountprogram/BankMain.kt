package com.example.bankaccountprogram

fun main(){
    val sundramsBankAcc = BankAcc("Sundram Kumar", 45.32)
    println(sundramsBankAcc.accHolder)


    sundramsBankAcc.deposit(6543.56)
    sundramsBankAcc.deposit(23.44)
    sundramsBankAcc.deposit(4552.44)
    sundramsBankAcc.deposit(224443.44)
    sundramsBankAcc.deposit(42323.44)
    sundramsBankAcc.deposit(233.44)

    sundramsBankAcc.withdraw(278165.07)
    sundramsBankAcc.displaytransacHist()
    println("${sundramsBankAcc.accHolder}'s balance is ${sundramsBankAcc.acctBal()}")

    val sarahsBankAcc = BankAcc("Sarah Singh", 0.0)
    sarahsBankAcc.deposit(64.21)
    sarahsBankAcc.deposit(45222.5)
    sarahsBankAcc.withdraw(452.1)
    sarahsBankAcc.displaytransacHist()
    println("${sarahsBankAcc.accHolder}'s balance is ${sarahsBankAcc.acctBal()}")
}