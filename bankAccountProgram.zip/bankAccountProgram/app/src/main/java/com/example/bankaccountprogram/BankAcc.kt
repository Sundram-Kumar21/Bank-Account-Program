package com.example.bankaccountprogram

class BankAcc(var accHolder: String, var accBal: Double) {
    private val transacHist = mutableListOf<String>()

    fun deposit(amount: Double){
        accBal += amount
        transacHist.add("$accHolder deposited  ₹$amount")
    }

    fun withdraw(amount: Double){
        if (amount <= accBal){
            accBal -= amount
            transacHist.add("$accHolder withdrew  ₹$amount")
        } else{
            println("ur too broke to withdraw $amount ")
        }
    }

    fun displaytransacHist(){
        println("transaction for $accHolder")
        for (transaction in transacHist){
            println(transaction)
        }
    }

    fun acctBal():Double{
        return accBal
    }


}